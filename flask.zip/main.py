from flask import Flask, render_template, session, request, redirect, url_for, flash, abort, jsonify
from jinja2 import TemplateNotFound
from datetime import datetime, timedelta
from flask_socketio import emit
from collections import OrderedDict
from time import sleep
import zipfile, json, threading




app = Flask(__name__)



@app.route("/", methods=['GET'])
@app.route("/home", methods=['GET'])
def home():

    dt = datetime.now()

    html_str = """<p>Company <span style='background-color:yellow'>AAA</span> replaces CEO <span style='background-color:lightblue'>XXX</span> with <span style='background-color:lightblue'>YYY</span>, effective from <span style='background-color:lightgreen'>2021-10-01</span>. </p>
    """

    return render_template('index.html', 
        t=dt,
        s=html_str
    )


    
@app.route("/annotate", methods=['GET'])
def annotate():
    # render some data to frontend
    
    data = """<p>On January 6, a mob attacked the US Capitol with shouts of "Hang Mike Pence." Then-President Donald Trump had told his faithful vice president, according to a new book, "I don't want to be your friend anymore" because Pence said he wouldn't overturn the will of the people who chose Joe Biden to be president, and keep Trump in office.</p>
        <p>Michael D&#39;Antonio</p>
        <p>Michael D'Antonio</p>
        <p>But now, eight months later, Pence is indignant about how much coverage media is giving the people who came for him at the Capitol and suggested that the goal of the coverage is to tarnish the reputations of the millions of people supporting Trump. As for the former President, adds Pence, "We parted amicably." In fact, he says they have spoken at least a dozen times since their administration ended with Biden's swearing-in on January 20.</p>
        <p>Pence is behaving like the middle school kid intimidated by a bully's lunch money protection racket. Fearful of fighting back, he instead brings a little extra money for the gang every day and says the head bully is really his good buddy.</p>
        <p>Pence offered his sunny view of Trump and his supporters in an interview with Sean Hannity of Fox News and on the "Ruthless" podcast. It was broadcast after Trump, who seems certain to seek a return to the Oval Office in 2024, was beginning to talk tough about potential primary opponents. In an interview with Yahoo News, he warned Florida Gov. Ron DeSantis about challenging him for the 2024 nomination. "If I faced him, I'd beat him like I would beat everyone else," said Trump.</p>
        <p>"Everyone else" seems to include Pence, who, as he travels from one primary state to another, shows every sign of making a serious bid for the presidency himself. He has a new political organization, aided by a panel of big-name advisers, and he recently convened a retreat for donors in Jackson Hole, Wyoming. According to Axios, he is aiming to raise $18 million by year's end. Add the work Pence is doing to help follow Republicans across the country and he's obviously trying to make his long-held dreams of the presidency come true.</p>
        """

    return render_template('annotate.html', data=data)




@app.route("/update", methods=['POST'])
def update():
    if request.method == 'POST':
        data = eval(request.form["data"])

        print("get client data =",data)

    return jsonify({"status": True, "data":data })


@app.route("/confirm_extraction", methods=['POST'])
def confirm_extraction():
    if request.method == 'POST':
        data = eval(request.form["data"])

        print("get client data =",data)

    return jsonify({"status": True, "data":data })








if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True, threaded=True)
